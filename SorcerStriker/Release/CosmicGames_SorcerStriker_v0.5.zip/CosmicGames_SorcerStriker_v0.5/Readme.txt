Github Page:

https://github.com/joanmarquesbesses/Sorcer-Striker/wiki

Members and Github accounts links:

Salvador Bernades - Designer

https://github.com/SalvaBernades

Andrea Doña - Managment

https://github.com/poderoculto5

Joan Marquès - Coding

https://github.com/joanmarquesbesses

Biel Liñal - QA Tester

https://github.com/Biellg

Justo Tiscornia - Artist

https://github.com/Jusstox

Description

Sorcer Striker, known in Japan as Mahou Daisakusen is a vertically scrolling shooter arcade game developed by Raizing and originally released in 1993 for Arcades. It is the first game in the Mahou trilogy, followed by Kingdom Grandprix and Dimahoo.

Controls:

ESC quit game (on the menu), in-game goes to menu

F1 Show colliders

F2 God mode

F3 Insta win

F4 Insta Lose

F5 Camera lock

W move up camera
 
A move left camera

S move down camera

D move right camera

Combat controls:

Arrow UP (move up)

Arrow DOWN (move down)

Arrow LEFT (move left) 

Arrow RIGHT (move right) 

Space interact(scenes), in-game shoot

